//
//  CountryData.swift
//  PhoneNumberApp
//
//  Created by Таня on 14.09.18.
//  Copyright © 2018 Mikhail. All rights reserved.
//

import Foundation

struct CountryData: Decodable {       
   var name: String
   var dial_code: String
}
